jQuery(document).ready(function($){

	function addProduct() {
		//this is just a product placeholder
		//you should insert an item with the selected product info
		//replace productId, productName, price and url with your real product info
		
		productId = productId + 1;
		//***这个是我需要插入的地方  购买的item插入购物里  但是总是没法实现
		var productAdded = $('<li>'+ $('.n1').text()+" "+'<span class="cd-price">'+$('.p1').text()+'</span><div class="gw_num"><em class="jian">-</em><input type="text" value="'+productId+'" class="num"/><em class="add">+</em></div><button href="#0" class="cd-item-remove cd-img-replace"></button></li>');
		//***这个是我需要插入的地方   
		cartList.append(productAdded); 
        
	}

function addToCart() {
		//var cartIsEmpty = cartWrapper.hasClass('empty');
		//update cart product list
		addProduct();

		//update number of items 
		//updateCartCount(cartIsEmpty);
		//update total price
		//updateCartTotal(trigger.data('price'), true);
		//show cart
		//cartWrapper.removeClass('empty');
	}
	var cartWrapper = $('.body');
	//product id - you don't need a counter in your real project but you can use your real product id
	var productId = 0;
	//if( cartWrapper.length > 0 ) {
		//store jQuery objects
		 
		var cartList = cartWrapper.find('ul').eq(productId);
		//var cartTotal = cartWrapper.find('.checkout').find('span');
		//var cartTrigger = cartWrapper.children('.cd-cart-trigger');
		//var cartCount = cartTrigger.children('.count')
		var addToCartBtn = $('.cd-add-to-cart');
		//var undo = cartWrapper.find('.undo');
		//var undoTimeoutId;

		//add product to cart

		
	    addToCartBtn.click(function(){
	        addToCart();
	    });
		
		
	//}

	//if you change this breakpoint in the style.css file (or _layout.scss if you use SASS), don't forget to update this value as well
	var $L = 1200,
		$menu_navigation = $('#main-nav'),
		$cart_trigger = $('#cd-cart-trigger'),
		$hamburger_icon = $('#cd-hamburger-menu'),
		$lateral_cart = $('#cd-cart'),
		$shadow_layer = $('#cd-shadow-layer');

	//open lateral menu on mobile
	$hamburger_icon.on('click', function(event){
		event.preventDefault();
		//close cart panel (if it's open)
		$lateral_cart.removeClass('speed-in');
		toggle_panel_visibility($menu_navigation, $shadow_layer, $('body'));
	});

	//open cart
	$cart_trigger.on('click', function(event){
		event.preventDefault();
		//close lateral menu (if it's open)
		$menu_navigation.removeClass('speed-in');
		toggle_panel_visibility($lateral_cart, $shadow_layer, $('body'));
	});

	//close lateral cart or lateral menu
	$shadow_layer.on('click', function(){
		$shadow_layer.removeClass('is-visible');
		// firefox transitions break when parent overflow is changed, so we need to wait for the end of the trasition to give the body an overflow hidden
		if( $lateral_cart.hasClass('speed-in') ) {
			$lateral_cart.removeClass('speed-in').on('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
				$('body').removeClass('overflow-hidden');
			});
			$menu_navigation.removeClass('speed-in');
		} else {
			$menu_navigation.removeClass('speed-in').on('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
				$('body').removeClass('overflow-hidden');
			});
			$lateral_cart.removeClass('speed-in');
		}
	});

	//move #main-navigation inside header on laptop
	//insert #main-navigation after header on mobile
	move_navigation( $menu_navigation, $L);
	$(window).on('resize', function(){
		move_navigation( $menu_navigation, $L);
		
		if( $(window).width() >= $L && $menu_navigation.hasClass('speed-in')) {
			$menu_navigation.removeClass('speed-in');
			$shadow_layer.removeClass('is-visible');
			$('body').removeClass('overflow-hidden');
		}

	});
});

function toggle_panel_visibility ($lateral_panel, $background_layer, $body) {
	if( $lateral_panel.hasClass('speed-in') ) {
		// firefox transitions break when parent overflow is changed, so we need to wait for the end of the trasition to give the body an overflow hidden
		$lateral_panel.removeClass('speed-in').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
			$body.removeClass('overflow-hidden');
		});
		$background_layer.removeClass('is-visible');

	} else {
		$lateral_panel.addClass('speed-in').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
			$body.addClass('overflow-hidden');
		});
		$background_layer.addClass('is-visible');
	}
}

function move_navigation( $navigation, $MQ) {
	if ( $(window).width() >= $MQ ) {
		$navigation.detach();
		$navigation.appendTo('header');
	} else {
		$navigation.detach();
		$navigation.insertAfter('header');
	}
}

    var that;
    $('.cd-item-remove').on('click',function(){
    	
            $('.jd_win').show();

            that = $(this);
    })

    $('.cancle').on('click',function(){
        $('.jd_win').hide();
    })
    $('.submit').on('click',function(){

        that.parent().remove();

        $('.jd_win').hide();
    })

	

